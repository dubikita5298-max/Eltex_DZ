#include <stdio.h>
#include <stdlib.h> 
#include <time.h>   
#include <unistd.h> 
#include "int_face.h"

void randomize (int* rand_n, int min, int max){
        (*rand_n) = (rand()%(max - min + 1)) + min;
        rand_n++;
}
//Функция для потоков-покупателей
void* buy(void* arg) {
    struct inf_buyers* arg_buy = (struct inf_buyers*)arg;//Приведение типов к структуре покупателей
    int qty_shp = arg_buy->qty_shop; //Кол-во магазинов
    int j = -1;                      //Индекс магазина в который будем входить
    int P = arg_buy->need_buyer;     //Потребность потока-покупателя
    int ID_b = arg_buy->ind_buyer;   //Идентификатор потока-покупателя
    unsigned int seed_buy = time(NULL) ^ pthread_self();//Переменная для генерации рандомных значений

    //Покупатель заходит в магазины, пока его потребность не станет равной нолю или меньше ноля
    while (P > 0) {
    j = rand_r(&seed_buy)%qty_shp;            //Каждую итерацию выбираем рандомный магазин

    pthread_mutex_lock(&(arg_buy->shop_inf[j].mut_shop));//Захватываем мьютекс
    int* T = &(arg_buy->shop_inf[j].product); //Ук-ль на кол-во тов. в выбранном маг, обновляем каждую итерацию цикла

    if ((*T) > 0){//Если в магазине есть товары, забираем всё
        printf("Покупатель %d, моя потребность %d товаров зашёл в Магазин %d, тов. в магазине %d\n", ID_b, P, (j+1), (*T));
        P = P - (*T);
        (*T) = 0;
        printf("Покупатель %d, потребность стала %d, вышел из Магазина %d, тов. в магазине стало %d\n",ID_b, P, (j+1), (*T));

        if (P <= 0){//Если покупатель исчерпал свою потребность
            pthread_mutex_unlock(&(arg_buy->shop_inf[j].mut_shop));//Высвобождаем мьютекс
            pthread_exit(0);                                       //Завершаем поток
        }
        else {
            pthread_mutex_unlock(&(arg_buy->shop_inf[j].mut_shop));//Высвобождаем мьютекс, после того как забрали товар
        }
    }
    //Если в магазине товаров не было высвобождаем мьютекс и засыпаем на 2 сек.
    else {
        pthread_mutex_unlock(&(arg_buy->shop_inf[j].mut_shop));
        printf("Покупатель %d ушёл в сон\n", ID_b);
        sleep(2);
    }    
  }
    return NULL;
} 


void* add(void* arg){

    struct inf_loader* arg_loader = (struct inf_loader*)arg; //Приведение типов к структуре погрузчика
    int qty_shp = arg_loader->qty_shop;   //Кол-во магазинов
    int j = -1;                           //Индекс магазина в который будем входить
    int add_prdct = arg_loader->add_prod; //Кол-во товара, которое будем добавлять
    char* ID_l = arg_loader->ind_loader;  //Идентификатор потока-погрузчика
    unsigned int seed_ldr = time(NULL);   //Переменная для генерации рандомных значений

    //Поток-погрузчик продолжает работать пока его переменная флаг больше ноля
    while (1){

        pthread_mutex_lock(&arg_loader->mut_flag);     //Захватываем мьютекс флага-завершения для проверки
        if ((arg_loader->close_flag) == 0){
            pthread_mutex_unlock(&arg_loader->mut_flag);
            break;
        }
        else {
            pthread_mutex_unlock(&arg_loader->mut_flag);
        }

        j = rand_r(&seed_ldr)%qty_shp;              //Каждую итерацию выбираем рандомный магазин
        pthread_mutex_lock(&(arg_loader->shop_inf[j].mut_shop));    //Захватываем мьютекс

        int* T = &(arg_loader->shop_inf[j].product);//Ук-ль на кол-во тов. в выбранном маг, обновляем каждую итерацию цикла
        printf("%s зашёл в М%d, тов. в М %d\n", ID_l, (j+1), (*T));
        (*T) =(*T) + add_prdct;                                     //Добавляем товар в магазин
        printf("%s вышел из М%d, тов. в М %d\n", ID_l, (j+1), (*T));

        pthread_mutex_unlock(&(arg_loader->shop_inf[j].mut_shop));  //Высвобождаем мьютекс
        sleep(1);                                                   //Засыпаем на 1 сек.
    }

    return NULL;
}