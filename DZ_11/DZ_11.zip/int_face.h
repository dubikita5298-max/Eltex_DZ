#ifndef INT_FACE_H     // Условие для исключения повторного присоединения файла
#define INT_FACE_H
#include <pthread.h> 

struct inf_buyers{             //Структура потока-покупателя
    int ind_buyer;             //Индекс покупателя
    int need_buyer;            //Кол-во товара нужного покупателю
    int qty_shop;              //Кол-во магазинов
    struct inf_shops* shop_inf;//Адрес структуры магазина
};

struct inf_loader{              //Структура потока-погрузчика
    int close_flag;             //Флаг для завершения потока
    char* ind_loader;           //Имя потока 
    int add_prod;               //Кол-во добавляемого товара
    int qty_shop;               //Кол-во магазинов   
    struct inf_shops* shop_inf; //Адрес структуры магазина
    pthread_mutex_t mut_flag;   //Переменная-мьютекс для захвата флага завершения потока
};

struct inf_shops{               //Структура магазина
    int product;                //Кол-во товара
    pthread_mutex_t mut_shop;   //Переменная-мьютекс для захвата магазина
};

void randomize (int*, int, int);//Прототип ф-ии рандомайзера
void* buy(void*);               //Прототип ф-ии потоков-покупателей
void* add(void*);               //Прототип ф-ии потока-погрузчика               

#endif