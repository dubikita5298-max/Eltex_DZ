#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>  
#include "int_face.h"
#define QTY_SHOP 5     //Кол-во магазинов
#define QTY_BUYER 3    //Кол-во покупателей
#define MIN_SHOP 990   //Мин знач кол-ва тов-ов в магазинах
#define MAX_SHOP 1100  //Макс знач кол-ва тов-ов в магазинах
#define MIN_BUYER 9900 //Мин знач кол-ва тов-ов нужных покупателям
#define MAX_BUYER 10100 //Макс знач кол-ва тов-ов нужных покупателям
#define LOAD_PROD 200  //Кол-во товаров передаваемых погрузчиком

int main(){

    int* result = NULL;               //Результат завершения потока
    pthread_t thread_buyer[QTY_BUYER];//Массив ID потоков-покупателей
    pthread_t thread_loader;          //ID потока-подгрузчика
    struct inf_buyers buyer[5];       //Массив структур покупателей 
    struct inf_shops shop[5];         //Массив структур магазинов
    struct inf_loader loader;         //Cтруктура погрузчика

    //Инициализируем поля структуры магазинов
    for (int i = 0; i < QTY_SHOP; i++){
        randomize(&shop[i].product, MIN_SHOP, MAX_SHOP);        //Генерируем кол-во товаров для магазинов
        if (pthread_mutex_init (&shop[i].mut_shop, NULL) != 0){ //Инициализируем мьютексы магазинов
            printf("Ошибка инициализации мьютекса\n");
            exit(EXIT_FAILURE);
        } 
    }

    //Инициализируем поля структуры потоков-покупателей
    for (int i = 0; i < QTY_BUYER; i++){
        randomize(&buyer[i].need_buyer,  MIN_BUYER, MAX_BUYER); //Генерируем кол-во товаров для покупателей
        buyer[i].shop_inf = &shop[0];                           //Адрес структуры 1-го магазина
        buyer[i].qty_shop = QTY_SHOP;                           //Кол-вол магазинов
    }

    //Инициализируем поля структуры погрузчика
    if (pthread_mutex_init (&loader.mut_flag, NULL) == 0) {
        loader.close_flag = 1;           //Переменная-флаг, для завершенияп потока-погрузчика, при значении
        loader.add_prod = LOAD_PROD;    //Кол-во товаров, которые погр. будет добавлять
        loader.ind_loader = "Погрузчик";//Строка-идентификатор (название потока)
        loader.qty_shop = QTY_SHOP;     //Кол-вол магазинов
        loader.shop_inf = &shop[0];     //Адрес структуры 1-го магазина
    }
    else {
        printf("Ошибка инициализации мьютекса\n");
        exit(EXIT_FAILURE);
    }


    //Выводим на экран товары в магазинах и потребность покупателей
    printf("\n");
    printf("Потребность покупателей:\n");
    for (int i = 0; i < QTY_BUYER; i++){
        printf("Покупатель %d - %d ",(i+1), buyer[i].need_buyer);
    }
    printf("\n");

    printf("Кол-во товаров в магазинах:\n");
    for (int i = 0; i < QTY_SHOP; i++){
        printf("Магазин %d - %d ",(i+1), shop[i].product);
    }
    printf("\n\n");

    //Создаём потоки-покупатели
    //Передаём инд. потока в структуру
    for (int i = 0; i < QTY_BUYER; i++){
        buyer[i].ind_buyer = i + 1;
        if (pthread_create(&thread_buyer[i], NULL, buy, &buyer[i]) != 0){
            printf("Ошибка создания потока %d\n",buyer[i].ind_buyer);
            exit(EXIT_FAILURE);
        }
    }

    //Создаём поток-погрузчик
    if (pthread_create (&thread_loader, NULL, add, &loader)!= 0){
        printf("Ошибка создания потока %s\n",loader.ind_loader);
        exit(EXIT_FAILURE);  
    }

    //Цикл ожидания потоков-покупателей
    for (int j = 0; j < QTY_BUYER; j++){
        if (pthread_join(thread_buyer[j],(void**)&result) == 0){
            printf("Успешно завершился поток %d\n", buyer[j].ind_buyer);
        }
        else{
            printf("Ошибка завершения потока %d\n",buyer[j].ind_buyer);
            exit(EXIT_FAILURE);
        }
    }

    //После завершения всех потоков-покупателей изменяем значения переменной-флага потока-погрузчика
    pthread_mutex_lock(&loader.mut_flag);//Захватываем мьютекс
    loader.close_flag = 0;
    pthread_mutex_unlock(&loader.mut_flag);//Высвобождаем мьютекс
    //Цикл ожидания потока-погрузчика
    if (pthread_join(thread_loader, (void**)&result) == 0){
        printf ("Успешно завершился поток %s\n",loader.ind_loader);
    }
    else{
        printf("Ошибка завершения потока %s\n",loader.ind_loader);
        exit(EXIT_FAILURE); 
    }

    return 0;
}
