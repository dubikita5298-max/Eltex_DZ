#ifndef INFACE_H     //Условие для исключения повторного присоединения файла
#define INFACE_H  

struct list {                   
    char *name;               
    int count;                 
};

void make_interface(void); //Прототип ф-ии формирования интерфейса 
void close_interface(void);//Прототип ф-ии закрытия интерфейса
void make_list_win(struct dirent**, int, int, int, char*);//Прототип ф-ии формирования списка директорий/файлов
int key_proc(struct dirent**, int, int*, int, char*);     //Прототип ф-ии обработки нажатия клавиш

#endif