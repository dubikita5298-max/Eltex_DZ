#include <ncurses.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <stdlib.h>
#include "inface.h"


WINDOW* win_big_l = NULL;  //Оснонове окно левое
WINDOW* win_inbig_l = NULL;//Окно внутри основного левого, для вывода содержимого дерикторий
WINDOW* win_big_r = NULL;  //Дополнительное окно правое
WINDOW* win_inbig_r = NULL;//Окно внутри дополнительного правого, для вывода содержимого дерикторий
WINDOW* win_small_l = NULL;//Окно-заголовок (левое)
WINDOW* win_small_r = NULL;//Окно-заголовок (правое)
WINDOW* win_down = NULL;   //Окно с информацией (нижнее)

//Ф-ия для создания интерфейса
void make_interface(void){

    initscr();                            //Инициализировали ncurse
    keypad(stdscr, TRUE); 
    start_color();                        //Включили поддержку цветов
    init_pair(1, COLOR_WHITE, COLOR_BLUE);//Создали цветовую пару,как основной цвет

    // Размеры окон и выводимый в них текст
    int sz_y_big = LINES - 6;
    int sz_x_big = COLS/2;
    int sz_y_small = 3;
    int sz_x_small = COLS/2;
    int sz_y_down = 3;
    int sz_x_down = COLS;
    char headline_L[] = "Window 1 (main)";      //Название левого окна
    char headline_R[] = "Window 2 (additional)";//Название правого окна
    char info[] = "Press: Q for quit | ENTER fop open directory | TAB for change window | Key UP/DOWN for navigate |"; //Текст для окна информации
   
    //Окно основное (левое) 
    win_big_l = newwin(sz_y_big, sz_x_big, 3, 0);//Создание окна
    wbkgd(win_big_l, COLOR_PAIR(1) | ' ');       //Применяем к окну цвет фона и цвет текста
    box(win_big_l,0,0);                          //Создаём рамку по периметру окна
    wrefresh(win_big_l);                         //Обновление (выгрузка из памяти в окно)
    //Окно внутри основного, где будет выводится список каталога (левое) 
    win_inbig_l = newwin(sz_y_big - 2, sz_x_big - 2, 4, 1); //Создание окна
    wbkgd(win_inbig_l, COLOR_PAIR(1) | ' ');                //Применяем к окну цвет фона и цвет текста
    wrefresh(win_inbig_l);                                  //Обновление (выгрузка из памяти в окно)

    //Окно вспомогательное (правое)
    win_big_r = newwin(sz_y_big, sz_x_big, 3, COLS/2);
    wbkgd(win_big_r, COLOR_PAIR(1) | ' ');
    box(win_big_r,0,0);
    wrefresh(win_big_r);
    //Окно внутри вспомогательного, где будет выводится список каталога (правое)
    win_inbig_r = newwin(sz_y_big - 2, sz_x_big - 2, 4, COLS/2 + 1);
    wbkgd(win_inbig_r, COLOR_PAIR(1) | ' ');
    wrefresh(win_inbig_r);

    //Окно-заголовок (левое)
    win_small_l = newwin(sz_y_small, sz_x_small, 0, 0);                        //Создание окна
    wbkgd(win_small_l, COLOR_PAIR(1) | ' ');                                   //Применяем к окну цвет фона и цвет текста
    wattron(win_small_l, COLOR_PAIR(1) | A_BOLD);                              //Включаем цвет и жирность
    mvwaddstr(win_small_l, 1, (sz_x_small - strlen(headline_L))/2, headline_L);//Перемещаем курсор в опр место и выводим текст
    wattroff(win_small_l, COLOR_PAIR(1) | A_BOLD);                             //Выключаем цвет и жирность
    box(win_small_l,0,0);                                                      //Создаём рамку по периметру окна
    wrefresh(win_small_l);                                                     //Обновление (выгрузка из памяти в окно)

   //Окно-заголовок (правое)
    win_small_r = newwin(sz_y_small, sz_x_small, 0, COLS/2);
    wbkgd(win_small_r, COLOR_PAIR(1) | ' ');       
    wattron(win_small_r, COLOR_PAIR(1) | A_BOLD);  
    mvwaddstr(win_small_r, 1, (sz_x_small - strlen(headline_R))/2, headline_R);
    wattroff(win_small_r, COLOR_PAIR(1) | A_BOLD); 
    box(win_small_r,0,0);  
    wrefresh(win_small_r);

    //Окно с информацией (нижнее)
    win_down = newwin(sz_y_down, sz_x_down, LINES - 3, 0);
    wbkgd(win_down, COLOR_PAIR(1) | ' ');
    mvwaddstr(win_down, 1, (sz_x_down - strlen(info))/2, info);
    box(win_down, 0,0);
    wrefresh(win_down);

    keypad(win_inbig_l, TRUE);   
    keypad(win_inbig_r, TRUE);  
    curs_set(0);         //Отключили курсор (мигание)
    noecho();            //Отключили отображение на экране вводимого с клавиатуры
}

//Ф-ия закрытия всех окон
void close_interface(void){
    delwin(win_inbig_l);
    delwin(win_inbig_r);
    delwin(win_small_l);
    delwin(win_small_r);
    delwin(win_down);

    delwin(win_big_l);
    delwin(win_big_r);

    endwin(); 
}

//Ф-ия ообновления (вывод содержимого дериктории)
//Ф-ия принимает ука-ль на структуру (mas), хранящую имена файлов/деректорий,
//кол-во элементов в этой структуре (size), номер текущей строки (str), переменную-флаг (change)
//указатель на строку - абс адрес тек. дериктории (cur_path)
void make_list_win (struct dirent** mas, int size, int str, int change, char*cur_path){
    int win_size = LINES - 9;//Кол-во строк, воводимые в окне (размер окна)
    WINDOW* winm = NULL;     //Для определения рабочего окна, в зависимости от переданного флага

    if (change == 0){
        winm = win_inbig_l;
    }
    else {
        winm = win_inbig_r;
    }

    werase(winm);
    int start_index;
    //Если кол-во элементов дериктории не помещается в размер окна
    if (str > win_size){ 
        start_index = str - 1;
    }
//Если кол-во элементов дериктории не помещается в размер окна
    else {
        start_index = 0;
    }
//Цикл для вывода содержимого дериктории
//Цикл ограничен размером окна
    for (int i = 1; i <= win_size; i++){
        int cur_index = start_index + i;
        //Дополнительное условие для выхода,
        //если индекс текущего элемента директории достиг конца директории
        if (cur_index >= size){
            break;
        }
        //Для подсветки элемента директории на котором находится пользователь
        if (cur_index == str){
             wattron(winm, A_REVERSE); 
        }
        //Вывод в окно имени файла/директории
         mvwprintw(winm, i, 0, "%s", mas[cur_index]->d_name);
         //Отключение подсветки для следующих за текущим каталогов
        if (cur_index == str){
             wattroff(winm, A_REVERSE); 
        }
    }

    //В нулевой строке выводится абсолютный адрес директории,
    //в которой находится пользователь
    mvwprintw(winm, 0, 0, "%s %s", "Current path:", cur_path);
    wrefresh(winm);//Обновление окна после всех изменений
}

//Ф-ия обработки нажатия клавиш
//Ф-ия принимает ука-ль на структуру (mas), хранящую имена файлов/деректорий,
//кол-во элементов в этой структуре (size), номер текущей строки (str), переменную-флаг (change)
//указатель на строку - абс адрес тек. дериктории (cur_path)
int key_proc(struct dirent** mas, int size, int* str, int change, char* cur_path){

    WINDOW* win = NULL;//Для определения рабочего окна, в зависимости от переданного флага
    if (change == 0){
        win = win_inbig_l;
    }
    else {
        win = win_inbig_r;
    }
         
    int key = wgetch(win);
    //Для обратной связи в вызывающую ф-ию передаётся int с определённым значением
    if (key == 'q' || key == 'Q'){  //Выход из менеджера, выз-ся ф-ия закртия интерфейса
        close_interface();
        return 0;                
    }

    else if (key == 10){          //Был нажат ENTER, открываетмя каталог
        return 1;                 
    }

    else if (key == '\t'){       //Был нажат TAB
        return 2;                
    }
    //Нажата клавиша UP, уменьшаем индекс строки и вызываем ф-ию для обновления окна
    else if (key == KEY_UP && (*str) != 1){
        (*str)--;
        make_list_win(mas, size, *str, change, cur_path);
        return 3;
    }
    //Нажата клавиша DOWN, уменьшаем индекс строки и вызываем ф-ию для обновления окна
    else if (key == KEY_DOWN && (*str) != size - 1){
        (*str)++;
        make_list_win (mas, size, *str, change, cur_path);
        return 3;
    }
    //Нажата любая другая клавиша 
    else {
        return 3;
    }
}