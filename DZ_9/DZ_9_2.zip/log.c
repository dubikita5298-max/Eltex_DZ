#include <ncurses.h>
#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <stdlib.h>
#include "inface.h"
#define S_PATH 1000

int main() {

    make_interface();
    int str_numl = 1;          //Переменная для индекса строки левого окна
    int str_numr = 1;          //Переменная для индекса строки правого окна
    int l = 0;                 //Переменная-флаг, для определения рабочего окна
    int r = 1;                 //Переменная-флаг, для определения рабочего окна
    int indicator = 0;         //Для окончания обшего цикла
    int change = 0;            //Для вызова функции обработки клавиш
    char path_l[S_PATH];       //Строка для абсолютного пути левого окна
    char path_r[S_PATH];       //Строка для абсолютного пути левого окна
    getcwd(path_l, S_PATH);    //Функция для определения пути (октуда зап-на программа) и сохр в строку
    getcwd(path_r, S_PATH);    //Функция для определения пути (октуда зап-на программа) и сохр в строку

    struct dirent **name_list_l = NULL;//Указатель на массив, в котором лежат указатели на структуры (левое окно)
    struct dirent **name_list_r = NULL;//Указатель на массив, в котором лежат указатели на структуры (правое окно)
    int nl = scandir(path_l, &name_list_l, NULL, alphasort); //Кол-во файлов в директрии, которое вернёт scandir (левое окно)
    int nr = scandir(path_r, &name_list_r, NULL, alphasort); //Кол-во файлов в директрии, которое вернёт scandir (правое окно)
    
    //При неудачном открытии директории закрываем интерфейс и выводим ошибку
    if (nl < 0 || nr < 0){ 
        perror("Не удалось получить доступ к директории");
        close_interface();
        exit(EXIT_FAILURE);
    }

    else{
        make_list_win(name_list_l, nl, str_numl, l, path_l);//Формируется список файлов/директорий в левом окне
        make_list_win(name_list_r, nr, str_numr, r, path_r);//Формируется список файлов/директорий в правом окне

        //Основной цикл, пока переменная indicator = 0, цикл продолжается 
        while (indicator == 0){

        //Бесконечный цикл для левого окна, закончится при нажатии TAB
            while(1){ 
        change = key_proc(name_list_l, nl, &str_numl, l, path_l);//В переменную вернётся интовое число, по которому определяется дальнейшее действие
        //Выход из программы (нажата q или Q)
        if (change == 0){     
            //Высвобождение выделенной динамической памяти для левого и правого окна
            for (int i = 0; i < nl; i++){
                free(name_list_l[i]);
            }
            free (name_list_l);

            for (int i = 0; i < nr; i++){
                free(name_list_r[i]);
            }
            free (name_list_r);
            indicator = 1; //В переменную записывается 1 - условие выхода из внешнего цикла
            break;
        }
        //Смена директории (нажат ENTER)
        else if (change == 1 && name_list_l[str_numl]->d_type == DT_DIR){ 
            //Идём назад в родительскую директорию
            //Затираем всё после последнего слеша
            if (strcmp(name_list_l[str_numl]->d_name, "..") == 0){
            char* slash = strrchr(path_l, '/');
            if (slash != NULL){
                if (slash != path_l){
                    *slash = '\0';
                }
                else {
                    *(slash + 1) = '\0';
                }
              }
            }
            //Идём в глубь директории
            //Склеиваем тек путь + слеш + имя директории, которую хотим открыть
            else {
            strcat(path_l,"/");
            strcat(path_l, name_list_l[str_numl]->d_name);
            }
                for (int i = 0; i < nl; i++) {
                    free(name_list_l[i]);
                }
                free (name_list_l);
             nl = scandir(path_l, &name_list_l, NULL, alphasort);
             //При неудачном открытии директории закрываем интерфейс и выводим ошибку
             if (nl < 0){
                perror("Не удалось открыть директорию");
                close_interface();
                exit(EXIT_FAILURE);

             }
             //Обновляем строку и выводим новый список
             else {
                str_numl = 1;
                make_list_win(name_list_l, nl, str_numl, l, path_l);

             }
        }
        // Завершение цикла, переход на цикл для правого окна, (нажат TAB)
        else if (change == 2){   
            break;
        }
        //Нажата клавиша up/down или любые другие
        //Для up/down в graphics изменяется индекс текущей строки
        else {
            continue;
        }
      }      


        // Бесконечный цикл для правого окна, закончится при нажатии TAB
            while(1){
                //Если программа не была закрыта в цикле для левого окна
                if (indicator ==  0) {
        change = key_proc(name_list_r, nr, &str_numr, r, path_r);

        if (change == 0){     
            for (int i = 0; i < nr; i++){
                free(name_list_r[i]);
            }
            for (int i = 0; i < nl; i++){
                free(name_list_l[i]);
            }
            free (name_list_r);
            free (name_list_l);
            indicator = 1;
            break;
        }

        else if (change == 1 && name_list_r[str_numr]->d_type == DT_DIR){ 
 
            if (strcmp(name_list_r[str_numr]->d_name, "..") == 0){
            char* slash = strrchr(path_r, '/');
            if (slash != NULL){
                if (slash != path_r){
                    *slash = '\0';
                }
                else {
                    *(slash + 1) = '\0';
                }
              }
            }

            else {
            strcat(path_r,"/");
            strcat(path_r, name_list_r[str_numr]->d_name);
            }
                for (int i = 0; i < nr; i++) {
                    free(name_list_r[i]);
                }
                free (name_list_r);
             nr = scandir(path_r, &name_list_r, NULL, alphasort);

             if (nr < 0){
                perror("Не удалось открыть директорию");
                close_interface();
                exit(EXIT_FAILURE);
             }

             else {
                str_numr = 1;
                make_list_win(name_list_r, nr, str_numr, r, path_r);
             }
        }

        else if (change == 2){ 
            break;
        }
        else {
            continue;
        }
    }
    else {
        break;
       }
     }     
   }
}
    return 0;
}