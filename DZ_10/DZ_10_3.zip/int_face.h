#ifndef INT_FACE_H     // Условие для исключения повторного присоединения файла
#define INT_FACE_H 


char* s_gets(char*, int);     //Прототип ф-ии для воода строки
void make_arg (char*, char**);//Прототип ф-ии для дробления строки на отдельные строки

#endif