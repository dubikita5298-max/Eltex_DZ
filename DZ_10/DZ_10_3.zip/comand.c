#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>    
#include <sys/wait.h> 
#include <sys/types.h> 
#include "int_face.h"

#define SIZE_S 100     //Размер строки, вводимой пользователем 
#define SIZE_AR 10     //Размер массива указателей на строки

int main() {

    int stat;          //Для кода возврата дочернего процесса
    pid_t pid;         //Для возвращаемого pid в fork()
    pid_t finish;      //Для возвращаемого pid в wait()
    char vvod[SIZE_S]; //Строка, вводимая пользователем
    char* arg[SIZE_AR];//Массив, хранящий указатели на строки-аргументы для передачи в exec()

    while(1){

        printf("Введите название программы и опции её запуска. Для выхода введите exit\n");
        s_gets(vvod, SIZE_S);//Вызов функции для воода строки

        //Елси введён exit -выход из программы
        if (strcmp(vvod, "exit") == 0) break;

        //Иначе- вызываем функцию формирования аргументов, создаём процесс
        make_arg(vvod, arg);
        pid = fork();

        //Процесс не удалось создать - завершение работы
        if (pid < 0) {
            perror("Ошибка создания процесса");
            exit(EXIT_FAILURE);
        }

        //Процесс создан, запускаем бинарник введённый пользователем
        else if (pid == 0){
            //printf("Запущен процесс с PID %d\n", getpid());
            //Елси не удалось запустить бинарник
            if (execvp(arg[0], arg) == -1){
                perror("Ошибка открытия бинарника");
            }
            //Попадаем сюда только в случае ошибки и передаём код ошибки в родителя
            exit(EXIT_FAILURE);          
        }

        //Родитель ждёт завершения ребёнка
        else {
            finish = wait(&stat);
            if (finish < 0){
                perror("Ошибка wait");
                exit(EXIT_FAILURE);
            }
        }
    }
    return 0;
}